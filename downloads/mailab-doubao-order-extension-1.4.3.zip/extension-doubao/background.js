chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'mailab-api') {
    callMailabApi(message)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((error) => sendResponse({ ok: false, error: error.message || '后端请求失败' }));
    return true;
  }
  if (message?.type === "CAPTURE_GET_CURRENT" || message?.type === "CAPTURE_REFRESH" || message?.type === "CAPTURE_CLEAR_CURRENT") {
    handleCaptureSnapshot(_sender, message)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((error) => sendResponse({ ok: false, error: error.message || "读取捕获结果失败" }));
    return true;
  }
  if (message?.type === "DOUBAO_RESOLVE_THREAD") {
    resolveDoubaoThreadShareUrl(message.url)
      .then((videoUrl) => sendResponse({ ok: true, data: { videoUrl } }))
      .catch((error) => sendResponse({ ok: false, error: error.message || "豆包分享链接解析失败" }));
    return true;
  }
  return false;
});

async function callMailabApi(message) {
  const serverUrl = normalizeServerUrl(message.serverUrl);
  const path = String(message.path || '');
  if (!serverUrl) {
    throw new Error('请填写公网后端地址，例如 https://api.example.com');
  }
  if (!/^https:\/\//i.test(serverUrl) && !/^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/i.test(serverUrl)) {
    throw new Error('公网后端请使用 HTTPS 地址；本地调试可用 http://127.0.0.1:端口');
  }
  if (!path.startsWith('/api/')) {
    throw new Error('后端接口路径无效');
  }

  const response = await fetch(`${serverUrl}${path}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(message.body || {})
  });
  const data = await safeJson(response);
  if (!response.ok) {
    return {
      ok: false,
      error: data.error || `后端请求失败 HTTP ${response.status}`,
      videoUrl: data.videoUrl || ''
    };
  }
  return data;
}

function normalizeServerUrl(value) {
  return String(value || '').trim().replace(/\/+$/, '');
}

async function safeJson(response) {
  const text = await response.text();
  try {
    return JSON.parse(text);
  } catch {
    return { ok: false, error: htmlErrorMessage(text, response.status) };
  }
}

function htmlErrorMessage(text, status) {
  const body = String(text || '');
  if (/504\s+Gateway\s+Time-out|Gateway\s+Time-out/i.test(body)) {
    return '后端处理超时：Nginx 反向代理等待时间太短，请在宝塔把 proxy_read_timeout 调到 600 秒以上。';
  }
  if (/502\s+Bad\s+Gateway/i.test(body)) {
    return '后端网关错误：请确认 PM2 服务正在运行，并检查宝塔反向代理目标地址。';
  }
  if (/<html[\s>]|<!doctype\s+html/i.test(body)) {
    return `服务器返回 HTML 错误页面${status ? ` HTTP ${status}` : ''}，请检查宝塔/Nginx 配置。`;
  }
  return body.slice(0, 160) || '后端返回异常';
}
const DEBUGGER_VERSION = "1.3";
const DOUBAO_SKILL_PACK_URL_PART = "doubao.com/samantha/skill/pack";
const DOLA_SKILL_PACK_URL_PART = "dola.com/samantha/skill/pack";
const ACTION_BAR_CONF_URL_PART = ".com/alice/slot/action_bar_v3/get_item_conf";
const DOUBAO_CHAIN_SINGLE_URL_PART = "doubao.com/im/chain/single";
const DOLA_CHAIN_SINGLE_URL_PART = "dola.com/im/chain/single";
const QAAB_SALT_HEX = "4dd4c2e6b83162090e52b3c7a6733ba4"
  + "1cb2462b829ab58a196b39db57177524"
  + "f49baf7f08e8d68d26a72e37c1a95a2f"
  + "1f05a51892aef2949732b62a38aadd58";

const fetchPatterns = [
  { urlPattern: `*${DOUBAO_SKILL_PACK_URL_PART}*`, requestStage: "Request" },
  { urlPattern: `*${DOLA_SKILL_PACK_URL_PART}*`, requestStage: "Request" },
  { urlPattern: `*${ACTION_BAR_CONF_URL_PART}*`, requestStage: "Response" },
  { urlPattern: `*${DOUBAO_CHAIN_SINGLE_URL_PART}*`, requestStage: "Response" },
  { urlPattern: `*${DOLA_CHAIN_SINGLE_URL_PART}*`, requestStage: "Response" }
];

const attachedTabs = new Set();
const tabMediaCache = new Map();
const responseFileBodyPromises = new Map();

chrome.runtime.onInstalled.addListener(attachExistingTabs);
chrome.runtime.onStartup.addListener(attachExistingTabs);

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  const tab = await safeGetTab(tabId);
  if (tab && shouldAttachToTab(tab.url)) {
    ensureAttached(tabId);
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const url = changeInfo.url || tab.url;
  if (changeInfo.url) {
    tabMediaCache.delete(tabId);
  }
  if (shouldAttachToTab(url)) {
    ensureAttached(tabId);
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  attachedTabs.delete(tabId);
  tabMediaCache.delete(tabId);
});

chrome.action.onClicked.addListener((tab) => {
  if (tab && tab.id) {
    ensureAttached(tab.id);
  }
});

chrome.debugger.onDetach.addListener((source) => {
  if (source.tabId) {
    attachedTabs.delete(source.tabId);
    setBadge(source.tabId, "");
  }
});

chrome.debugger.onEvent.addListener((source, method, params) => {
  if (method === "Fetch.requestPaused" && source.tabId && params) {
    handlePausedRequest(source.tabId, params);
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (!message || message.type !== "DOWNLOAD_MEDIA" || !isHttpUrl(message.url)) {
    return;
  }

  chrome.downloads.download({
    url: message.url,
    saveAs: false
  }).catch((error) => {
    console.warn("download failed:", error);
  });
});

async function attachExistingTabs() {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (tab.id && shouldAttachToTab(tab.url)) {
      ensureAttached(tab.id);
    }
  }
}

async function safeGetTab(tabId) {
  try {
    return await chrome.tabs.get(tabId);
  } catch {
    return null;
  }
}

function shouldAttachToTab(url) {
  return typeof url === "string"
    && /^https?:\/\//i.test(url)
    && (url.includes("doubao.com") || url.includes("dola.com"));
}

async function ensureAttached(tabId) {
  if (attachedTabs.has(tabId)) {
    return;
  }

  try {
    await attachDebugger(tabId);
  } catch (error) {
    console.warn("debugger attach failed:", error.message || error);
  }

  try {
    await sendCommand(tabId, "Fetch.enable", { patterns: fetchPatterns });
    attachedTabs.add(tabId);
    setBadge(tabId, "ON");
  } catch (error) {
    console.warn("Fetch.enable failed:", error.message || error);
    setBadge(tabId, "");
  }
}

function attachDebugger(tabId) {
  return new Promise((resolve, reject) => {
    chrome.debugger.attach({ tabId }, DEBUGGER_VERSION, () => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve();
    });
  });
}

function sendCommand(tabId, method, params = {}) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId }, method, params, (result) => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve(result);
    });
  });
}

async function handlePausedRequest(tabId, event) {
  const requestId = event.requestId;
  const request = event.request || {};
  const url = request.url || "";

  try {
    if (url.includes(DOUBAO_SKILL_PACK_URL_PART)) {
      await fulfillJsonFile(tabId, requestId, request.method, "doubao-skill-pack-response.json");
      return;
    }

    if (url.includes(DOLA_SKILL_PACK_URL_PART)) {
      await fulfillJsonFile(tabId, requestId, request.method, "dola-skill-pack-response.json");
      return;
    }

    if (url.includes(ACTION_BAR_CONF_URL_PART)) {
      await rewriteActionBarConfigResponse(tabId, event);
      return;
    }

    if (url.includes(DOUBAO_CHAIN_SINGLE_URL_PART)) {
      await inspectChainSingleResponse(tabId, event, "doubao");
      return;
    }

    if (url.includes(DOLA_CHAIN_SINGLE_URL_PART)) {
      await inspectChainSingleResponse(tabId, event, "dola");
      return;
    }

    await continueRequest(tabId, requestId);
  } catch (error) {
    console.warn("request handling failed:", error.message || error);
    await continueRequest(tabId, requestId).catch(() => {});
  }
}

async function fulfillJsonFile(tabId, requestId, method, fileName) {
  if ((method || "").toUpperCase() === "OPTIONS") {
    await sendCommand(tabId, "Fetch.fulfillRequest", {
      requestId,
      responseCode: 204,
      responsePhrase: "No Content",
      responseHeaders: corsHeaders()
    });
    return;
  }

  const body = await getResponseFileBody(fileName);
  await sendCommand(tabId, "Fetch.fulfillRequest", {
    requestId,
    responseCode: 200,
    responsePhrase: "OK",
    responseHeaders: responseHeadersForTextBody(corsHeaders(), body),
    body: toBase64Utf8(body)
  });
}

function continueRequest(tabId, requestId) {
  return sendCommand(tabId, "Fetch.continueRequest", { requestId });
}

async function rewriteActionBarConfigResponse(tabId, event) {
  const response = await getPausedResponseBody(tabId, event.requestId);
  const patchedBody = patchActionBarDuration(response.body);

  await sendCommand(tabId, "Fetch.fulfillRequest", {
    requestId: event.requestId,
    responseCode: event.responseStatusCode || 200,
    responsePhrase: event.responseStatusText || "OK",
    responseHeaders: responseHeadersForTextBody(event.responseHeaders || [], patchedBody),
    body: toBase64Utf8(patchedBody)
  });
}

async function inspectChainSingleResponse(tabId, event, source) {
  const sourceKey = `${source}:${event.requestId}`;
  const response = await getPausedResponseBody(tabId, event.requestId);

  let items = [];
  try {
    const json = JSON.parse(response.body);
    if (source === "doubao") {
      items = await extractDoubaoItems(json, response.body);
    } else {
      items = extractDolaItems(json);
    }
  } catch (error) {
    console.warn(`${source} chain parse failed:`, error.message || error);
  }

  if (items.length) {
    const snapshot = await cacheMediaForTab(tabId, {
      type: "MEDIA_FOUND",
      sourceKey,
      source,
      items
    });
    await sendToTab(tabId, snapshot);
  } else {
    await sendToTab(tabId, {
      type: "MEDIA_STATUS",
      sourceKey,
      keepItems: true,
      text: "未提取到资源"
    });
  }

  await sendCommand(tabId, "Fetch.fulfillRequest", {
    requestId: event.requestId,
    responseCode: event.responseStatusCode || 200,
    responsePhrase: event.responseStatusText || "OK",
    responseHeaders: responseHeadersForTextBody(event.responseHeaders || [], response.body),
    body: toBase64Utf8(response.body)
  });
}

async function handleCaptureSnapshot(sender, message) {
  const tabId = sender?.tab?.id;
  if (!tabId) {
    throw new Error("未识别当前标签页");
  }
  if (message?.type === "CAPTURE_CLEAR_CURRENT") {
    tabMediaCache.delete(tabId);
    return {
      type: "MEDIA_STATUS",
      text: "已清空当前页面捕获记录"
    };
  }
  const tab = await safeGetTab(tabId);
  if (tab?.url && shouldAttachToTab(tab.url)) {
    ensureAttached(tabId);
  }
  const cached = tabMediaCache.get(tabId);
  if (cached?.items?.length) {
    return {
      type: "MEDIA_FOUND",
      sourceKey: cached.sourceKey,
      source: cached.source,
      pageUrl: cached.pageUrl,
      updatedAt: cached.updatedAt,
      fromCache: true,
      items: cached.items
    };
  }
  return {
    type: "MEDIA_STATUS",
    keepItems: true,
    text: message?.type === "CAPTURE_REFRESH"
      ? "当前页面暂无缓存结果，请在豆包/Dola 页面生成或切换一次结果后再试。"
      : "等待豆包/Dola 生成结果"
  };
}

async function cacheMediaForTab(tabId, snapshot) {
  const tab = await safeGetTab(tabId);
  const items = curateCapturedItems(snapshot.items || []);
  const cached = {
    type: "MEDIA_FOUND",
    sourceKey: snapshot.sourceKey,
    source: snapshot.source || "",
    pageUrl: tab?.url || "",
    updatedAt: Date.now(),
    items
  };
  tabMediaCache.set(tabId, cached);
  return cached;
}

function curateCapturedItems(items) {
  const seen = new Set();
  const normalized = [];
  for (const item of items) {
    const type = item?.type === "image" ? "image" : "video";
    const url = normalizeMediaUrl(item?.url || "");
    if (!url || seen.has(`${type}:${url}`)) {
      continue;
    }
    seen.add(`${type}:${url}`);
    normalized.push({
      type,
      url,
      score: mediaScore(type, url)
    });
  }

  const videos = normalized
    .filter((item) => item.type === "video")
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .map((item, index) => ({ type: item.type, url: item.url, recommended: index === 0 }));
  const images = normalized
    .filter((item) => item.type === "image")
    .slice(-3)
    .map((item) => ({ type: item.type, url: item.url }));
  return [...videos, ...images];
}

function normalizeMediaUrl(url) {
  if (!isHttpUrl(url)) {
    return "";
  }
  try {
    return new URL(String(url).replace(/\\u0026/g, "&")).toString();
  } catch {
    return "";
  }
}

function mediaScore(type, url) {
  if (type !== "video") {
    return 0;
  }
  const text = String(url || "");
  let score = 0;
  if (/download=true/i.test(text)) score += 1000;
  if (/mime_type=video_mp4|\.mp4(?:[?#]|$)/i.test(text)) score += 500;
  if (/logo_type=unwatermarked|channel=no|watermark=false/i.test(text)) score += 250;
  if (/watermark|logo_type=watermarked|tip\.mp4/i.test(text)) score -= 500;
  const br = text.match(/[?&](?:br|bitrate|bt)=(\d+)/i);
  if (br) score += Math.min(Number(br[1]) || 0, 10000) / 10;
  return score;
}

async function getPausedResponseBody(tabId, requestId) {
  const response = await sendCommand(tabId, "Fetch.getResponseBody", { requestId });
  return {
    body: response.base64Encoded ? fromBase64Utf8(response.body) : response.body
  };
}

async function extractDoubaoItems(json, rawBody) {
  const items = [];
  const seenUrls = new Set();

  for (const url of findImageOriRawUrls(json)) {
    addItem(items, seenUrls, "image", url);
  }

  for (const fallbackApi of findDoubaoFallbackApis(json, rawBody)) {
    const videoUrl = await getDoubaoVideoUrlFromFallbackApi(fallbackApi);
    addItem(items, seenUrls, "video", videoUrl);
  }

  return items;
}

function findDoubaoFallbackApis(json, rawBody) {
  const apis = new Set();

  for (const value of findValuesByKey(json, "fallback_api")) {
    addFallbackApi(apis, value);
  }

  const patterns = [
    /fallback_api\\":\\"(.*?)\\"/g,
    /"fallback_api"\s*:\s*"([^"]+)"/g
  ];

  for (const pattern of patterns) {
    let match = pattern.exec(rawBody);
    while (match) {
      addFallbackApi(apis, decodeJsonEscapedFragment(match[1]));
      match = pattern.exec(rawBody);
    }
  }

  return Array.from(apis);
}

function addFallbackApi(apis, value) {
  if (typeof value !== "string" || !value) {
    return;
  }

  const url = decodeJsonEscapedFragment(value);
  if (isHttpUrl(url)) {
    apis.add(url);
  }
}

function decodeJsonEscapedFragment(value) {
  let text = value;
  for (let index = 0; index < 3; index += 1) {
    try {
      const decoded = JSON.parse(`"${text.replace(/"/g, '\\"')}"`);
      if (decoded === text) {
        break;
      }
      text = decoded;
    } catch {
      break;
    }
  }
  return text.replace(/\\u0026/gi, "&").replace(/\\u002f/gi, "/").replace(/\\\//g, "/");
}

async function resolveDoubaoThreadShareUrl(value) {
  const shareUrl = normalizeDoubaoThreadShareUrl(value);
  if (!shareUrl) {
    throw new Error("仅支持公开的豆包 /thread/ 分享链接");
  }
  const pageResponse = await fetch(shareUrl, {
    method: "GET",
    credentials: "omit",
    headers: {
      accept: "text/html,application/xhtml+xml",
      "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/140.0.0.0 Safari/537.36"
    }
  });
  if (!pageResponse.ok) {
    throw new Error(`豆包分享页请求失败 HTTP ${pageResponse.status}`);
  }
  const html = await pageResponse.text();
  const fallbackApis = findDoubaoFallbackApisFromPageHtml(html);
  if (!fallbackApis.length) {
    throw new Error("公开分享页中没有 fallback_api");
  }
  for (const fallbackApi of fallbackApis) {
    const videoUrl = await getDoubaoVideoUrlFromFallbackApi(fallbackApi);
    if (isUnwatermarkedDoubaoVideoUrl(videoUrl)) {
      return videoUrl;
    }
  }
  throw new Error("豆包无水印视频直链解析失败");
}

function normalizeDoubaoThreadShareUrl(value) {
  const match = String(value || "").trim().match(/https:\/\/www\.doubao\.com\/thread\/[^\s"'<>?#]+/i);
  if (!match) {
    return "";
  }
  try {
    const url = new URL(match[0]);
    if (url.protocol !== "https:" || url.hostname !== "www.doubao.com" || !/^\/thread\/[^/]+\/?$/.test(url.pathname)) {
      return "";
    }
    return `${url.origin}${url.pathname.replace(/\/$/, "")}`;
  } catch {
    return "";
  }
}

function findDoubaoFallbackApisFromPageHtml(html) {
  const text = String(html || "");
  const markerIndex = text.indexOf("fallback_api");
  if (markerIndex < 0) {
    return [];
  }
  const neighborhood = decodeJsonEscapedFragment(text.slice(Math.max(0, markerIndex - 1000), markerIndex + 8000))
    .replace(/&amp;|&#38;|&#x26;/gi, "&");
  const candidates = neighborhood.match(/https:\/\/[^\s"'<>\\]+/g) || [];
  const apis = [];
  for (const candidate of candidates) {
    try {
      const url = new URL(candidate);
      if ((url.hostname === "snssdk.com" || url.hostname.endsWith(".snssdk.com")) && url.pathname.includes("/video/fplay/")) {
        apis.push(url.toString());
      }
    } catch {
      // Try the next candidate.
    }
  }
  return Array.from(new Set(apis));
}

function isUnwatermarkedDoubaoVideoUrl(value) {
  if (!isHttpUrl(value)) {
    return false;
  }
  try {
    const url = new URL(value);
    return url.protocol === "https:" && url.searchParams.get("lr") === "unwatermarked";
  } catch {
    return false;
  }
}

async function getDoubaoVideoUrlFromFallbackApi(fallbackApi) {
  try {
    const url = replaceQueryParams(fallbackApi, {
	  channel: "no",
      codec_type: "8",
      logo_type: "unwatermarked"
    });
    const response = await fetch(url, {
      method: "GET",
      credentials: "omit",
      headers: {
        "accept": "application/json,text/plain,*/*"
      }
    });
    const payload = await response.json();
    const data = getVideoData(payload);
    const token = pickMainUrlToken(data);
    if (!token) {
      return "";
    }
    return await decodeMainUrl(token, findKeySeedDeep(payload));
  } catch (error) {
    console.warn("doubao fallback_api failed:", error.message || error);
    return "";
  }
}

function replaceQueryParams(url, params) {
  const parsedUrl = new URL(url);
  for (const [key, value] of Object.entries(params)) {
    parsedUrl.searchParams.set(key, value);
  }
  return parsedUrl.toString();
}

function getVideoData(payload) {
  const videoInfo = payload?.video_info || payload?.data?.video_info || payload;
  const data = videoInfo?.data || videoInfo;
  return data && typeof data === "object" ? data : {};
}

function pickMainUrlToken(data) {
  const videoList = data?.video_list;
  const entries = videoList && typeof videoList === "object" && Object.keys(videoList).length
    ? Object.values(videoList)
    : [data];
  let best = null;

  for (const entry of entries) {
    if (!entry || typeof entry !== "object") {
      continue;
    }
    const token = entry.main_url || entry.play_url || "";
    if (typeof token !== "string" || !token.trim()) {
      continue;
    }
    const score = Number(entry.bitrate || entry.real_bitrate || 0)
      + Number(entry.vwidth || entry.width || 0) * Number(entry.vheight || entry.height || 0);
    if (!best || score > best.score) {
      best = { token: token.trim(), score };
    }
  }

  return best ? best.token : "";
}

function findKeySeedDeep(value, depth = 0) {
  if (depth > 10 || value == null) {
    return "";
  }

  if (typeof value === "string") {
    let match = value.match(/(?:^|[?&])key_seed=([^&"'<>\\\s]+)/i);
    if (match) {
      return decodeURIComponent(match[1]);
    }
    match = value.match(/["']key_seed["']\s*:\s*["']([^"']+)/i);
    return match ? decodeURIComponent(match[1]) : "";
  }

  if (typeof value !== "object") {
    return "";
  }

  if (typeof value.key_seed === "string" && value.key_seed.trim()) {
    return value.key_seed.trim();
  }

  for (const item of Object.values(value)) {
    const hit = findKeySeedDeep(item, depth + 1);
    if (hit) {
      return hit;
    }
  }

  return "";
}

async function decodeMainUrl(token, keySeed = "") {
  if (isHttpUrl(token)) {
    return token;
  }

  const plainUrl = tryDecodeBase64Url(token);
  if (plainUrl) {
    return plainUrl;
  }

  if (token.startsWith("qAAB") && keySeed) {
    return await decodeQaabToken(token, keySeed);
  }

  return "";
}

function tryDecodeBase64Url(token) {
  const bytes = base64DecodeLoose(token);
  if (!bytes) {
    return "";
  }
  const text = asciiUrlFromBytes(bytes);
  return isHttpUrl(text) ? text : "";
}

function base64DecodeLoose(text) {
  const input = String(text || "").trim();
  const variants = [
    input,
    input.replace(/[$@#]/g, (char) => ({ "$": "_", "@": "/", "#": "." }[char])),
    input.replace(/[$@#]/g, (char) => ({ "$": "+", "@": "/", "#": "=" }[char]))
  ];
  const seen = new Set();

  for (const candidate of variants) {
    if (!candidate || seen.has(candidate)) {
      continue;
    }
    seen.add(candidate);
    try {
      const normalized = padBase64(candidate).replace(/-/g, "+").replace(/_/g, "/");
      const binary = atob(normalized);
      const bytes = new Uint8Array(binary.length);
      for (let index = 0; index < binary.length; index += 1) {
        bytes[index] = binary.charCodeAt(index);
      }
      return bytes;
    } catch {
      // Try the next variant.
    }
  }

  return null;
}

function padBase64(text) {
  const pad = (4 - (text.length % 4)) % 4;
  return text + "=".repeat(pad);
}

function asciiUrlFromBytes(bytes) {
  if (!bytes || !bytes.length) {
    return "";
  }
  for (const byte of bytes) {
    if (byte !== 9 && byte !== 10 && byte !== 13 && (byte < 32 || byte > 126)) {
      return "";
    }
  }
  return new TextDecoder().decode(bytes);
}

async function decodeQaabToken(token, keySeed) {
  const data = base64DecodeLoose(token);
  const seed = base64DecodeLoose(keySeed);
  if (!data || !seed) {
    return "";
  }

  const digest1 = await crypto.subtle.digest("SHA-512", seed.slice(0, 32));
  const salt = hexToBytes(QAAB_SALT_HEX);
  const digest2Input = concatBytes(new Uint8Array(digest1), salt);
  const digest2 = new Uint8Array(await crypto.subtle.digest("SHA-512", digest2Input));
  const key = digest2.slice(0, 16);
  const iv = digest2.slice(16, 32);
  const attempts = [];

  if (data.length >= 4 && data[0] === 0xa8 && data[1] === 0x00 && data[2] === 0x01 && data[3] === 0x00) {
    attempts.push({ payload: data.slice(4), key, iv });
    attempts.push({ payload: data.slice(4), key: iv, iv: key });
    if (data.length > 36) {
      attempts.push({ payload: data.slice(36), key, iv: data.slice(20, 36) });
      attempts.push({ payload: data.slice(36), key, iv });
    }
  } else {
    attempts.push({ payload: data, key, iv });
  }

  for (const attempt of attempts) {
    const url = await decryptAesCbcUrl(attempt.payload, attempt.key, attempt.iv);
    if (url) {
      return url;
    }
  }

  return "";
}

async function decryptAesCbcUrl(payload, keyBytes, ivBytes) {
  if (!payload.length || payload.length % 16 !== 0) {
    return "";
  }

  try {
    const key = await crypto.subtle.importKey("raw", keyBytes, "AES-CBC", false, ["decrypt"]);
    const plain = new Uint8Array(await crypto.subtle.decrypt({ name: "AES-CBC", iv: ivBytes }, key, payload));
    const direct = asciiUrlFromBytes(plain);
    if (isHttpUrl(direct)) {
      return direct;
    }
    const stripped = stripPkcs7(plain);
    const url = asciiUrlFromBytes(stripped);
    return isHttpUrl(url) ? url : "";
  } catch {
    return "";
  }
}

function stripPkcs7(bytes) {
  if (!bytes || !bytes.length) {
    return new Uint8Array();
  }
  const pad = bytes[bytes.length - 1];
  if (pad < 1 || pad > 16 || pad > bytes.length) {
    return bytes;
  }
  for (let index = bytes.length - pad; index < bytes.length; index += 1) {
    if (bytes[index] !== pad) {
      return bytes;
    }
  }
  return bytes.slice(0, bytes.length - pad);
}

function hexToBytes(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let index = 0; index < bytes.length; index += 1) {
    bytes[index] = parseInt(hex.slice(index * 2, index * 2 + 2), 16);
  }
  return bytes;
}

function concatBytes(first, second) {
  const bytes = new Uint8Array(first.length + second.length);
  bytes.set(first, 0);
  bytes.set(second, first.length);
  return bytes;
}

function extractDolaItems(json) {
  const items = [];
  const seenUrls = new Set();

  for (const url of findImageOriRawUrls(json)) {
    addItem(items, seenUrls, "image", url);
  }

  for (const encodedUrl of findDolaEncodedVideoUrls(json)) {
    const url = decodeBase64Url(encodedUrl);
    addItem(items, seenUrls, "video", url);
  }

  return items;
}

function findDolaEncodedVideoUrls(json) {
  const values = [];
  for (const value of findValuesByKey(json, "man_url")) {
    values.push(value);
  }
  for (const value of findValuesByKey(json, "main_url")) {
    values.push(value);
  }
  return values;
}

function patchActionBarDuration(body) {
  try {
    const json = JSON.parse(body);
    const changed = patchNestedJsonStrings(json);
    return changed ? JSON.stringify(json) : body;
  } catch (error) {
    console.warn("patch action bar duration failed:", error.message || error);
    return body;
  }
}

function patchNestedJsonStrings(value, seen = new Set()) {
  if (value == null || typeof value !== "object" || seen.has(value)) {
    return false;
  }

  seen.add(value);
  let changed = false;

  if (Array.isArray(value)) {
    for (const item of value) {
      changed = patchNestedJsonStrings(item, seen) || changed;
    }
    return changed;
  }

  for (const key of Object.keys(value)) {
    const child = value[key];
    if (typeof child === "string") {
      const patchedString = patchJsonStringDuration(child);
      if (patchedString !== child) {
        value[key] = patchedString;
        changed = true;
      }
    } else {
      changed = patchNestedJsonStrings(child, seen) || changed;
    }
  }

  return changed;
}

function patchJsonStringDuration(text) {
  if (!text || (!text.includes("时长") && !text.includes("鏃堕暱"))) {
    return text;
  }

  try {
    const json = JSON.parse(text);
    const changed = patchDurationSelector(json);
    return changed ? JSON.stringify(json) : text;
  } catch {
    return text;
  }
}

function patchDurationSelector(value, seen = new Set()) {
  if (value == null || typeof value !== "object" || seen.has(value)) {
    return false;
  }

  seen.add(value);
  let changed = false;

  if (Array.isArray(value)) {
    for (const item of value) {
      changed = patchDurationSelector(item, seen) || changed;
    }
    return changed;
  }

  if ((value.label === "时长" || value.label === "鏃堕暱") && Array.isArray(value.option_list)) {
    const has15s = value.option_list.some((option) => option && option.option_key === "15");
    if (!has15s) {
      const tenSecondIndex = value.option_list.findIndex((option) => option && option.option_key === "10");
      const insertIndex = tenSecondIndex >= 0 ? tenSecondIndex + 1 : value.option_list.length;
      value.option_list.splice(insertIndex, 0, createFifteenSecondOption(value.option_list));
      changed = true;
    }
  }

  for (const key of Object.keys(value)) {
    const child = value[key];
    if (typeof child === "string") {
      const patchedString = patchJsonStringDuration(child);
      if (patchedString !== child) {
        value[key] = patchedString;
        changed = true;
      }
    } else {
      changed = patchDurationSelector(child, seen) || changed;
    }
  }

  return changed;
}

function createFifteenSecondOption(optionList) {
  const maxId = optionList.reduce((maxValue, option) => {
    const id = Number(option?.id);
    return Number.isFinite(id) ? Math.max(maxValue, id) : maxValue;
  }, 0);

  return {
    id: maxId + 1,
    display_text: "15s",
    message_text: "",
    option_key: "15"
  };
}

function findImageOriRawUrls(value) {
  const urls = [];
  walkJsonAndStrings(value, (node) => {
    if (node && typeof node === "object" && !Array.isArray(node)) {
      const image = node.image_ori_raw;
      if (image && typeof image === "object" && isHttpUrl(image.url)) {
        urls.push(image.url);
      }
    }
  });
  return urls;
}

function findValuesByKey(value, targetKey) {
  const values = [];
  walkJsonAndStrings(value, (node) => {
    if (!node || typeof node !== "object" || Array.isArray(node)) {
      return;
    }
    if (Object.prototype.hasOwnProperty.call(node, targetKey)) {
      values.push(node[targetKey]);
    }
  });
  return values;
}

function walkJsonAndStrings(value, visitor, seen = new Set()) {
  if (value == null) {
    return;
  }

  if (typeof value === "string") {
    const parsed = parseJsonString(value);
    if (parsed !== null) {
      walkJsonAndStrings(parsed, visitor, seen);
    }
    return;
  }

  if (typeof value !== "object" || seen.has(value)) {
    return;
  }

  seen.add(value);
  visitor(value);

  if (Array.isArray(value)) {
    for (const item of value) {
      walkJsonAndStrings(item, visitor, seen);
    }
    return;
  }

  for (const key of Object.keys(value)) {
    walkJsonAndStrings(value[key], visitor, seen);
  }
}

function parseJsonString(text) {
  const trimmed = text.trim();
  if (!trimmed || (!trimmed.startsWith("{") && !trimmed.startsWith("["))) {
    return null;
  }

  try {
    return JSON.parse(trimmed);
  } catch {
    return null;
  }
}

function addItem(items, seenUrls, type, url) {
  if (!isHttpUrl(url) || seenUrls.has(url)) {
    return;
  }
  seenUrls.add(url);
  items.push({ type, url });
}

function decodeBase64Url(value) {
  if (typeof value !== "string" || !value) {
    return "";
  }

  if (isHttpUrl(value)) {
    return value;
  }

  try {
    const padded = value.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(value.length / 4) * 4, "=");
    const decoded = fromBase64Utf8(padded);
    return isHttpUrl(decoded) ? decoded : "";
  } catch {
    return "";
  }
}

function responseHeadersForTextBody(headers, body) {
  const contentLength = String(new TextEncoder().encode(body).length);
  const nextHeaders = [];
  let hasContentType = false;
  let hasContentLength = false;

  for (const header of headers) {
    const name = header.name || "";
    const lowerName = name.toLowerCase();
    if (lowerName === "content-encoding") {
      continue;
    }

    if (lowerName === "content-type") {
      hasContentType = true;
      nextHeaders.push({ name, value: "application/json; charset=utf-8" });
      continue;
    }

    if (lowerName === "content-length") {
      hasContentLength = true;
      nextHeaders.push({ name, value: contentLength });
      continue;
    }

    nextHeaders.push(header);
  }

  if (!hasContentType) {
    nextHeaders.push({ name: "content-type", value: "application/json; charset=utf-8" });
  }

  if (!hasContentLength) {
    nextHeaders.push({ name: "content-length", value: contentLength });
  }

  return nextHeaders;
}

function getResponseFileBody(fileName) {
  if (!responseFileBodyPromises.has(fileName)) {
    responseFileBodyPromises.set(fileName, fetch(chrome.runtime.getURL(fileName)).then((response) => response.text()));
  }
  return responseFileBodyPromises.get(fileName);
}

function corsHeaders() {
  return [
    { name: "access-control-allow-origin", value: "*" },
    { name: "access-control-allow-credentials", value: "true" },
    { name: "access-control-allow-methods", value: "GET, POST, OPTIONS" },
    { name: "access-control-allow-headers", value: "*" }
  ];
}

function toBase64Utf8(text) {
  const bytes = new TextEncoder().encode(text);
  let binary = "";
  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }
  return btoa(binary);
}

function fromBase64Utf8(base64Text) {
  const binary = atob(base64Text);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return new TextDecoder().decode(bytes);
}

function isHttpUrl(url) {
  return typeof url === "string" && /^https?:\/\//i.test(url);
}

async function sendToTab(tabId, message) {
  try {
    await chrome.tabs.sendMessage(tabId, message);
  } catch (error) {
    console.warn("send panel message failed:", error.message || error);
  }
}

function setBadge(tabId, text) {
  chrome.action.setBadgeText({ tabId, text }).catch(() => {});
  chrome.action.setBadgeBackgroundColor({ tabId, color: "#166534" }).catch(() => {});
}
